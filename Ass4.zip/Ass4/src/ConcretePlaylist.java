import java.util.ArrayList;
import java.util.List;

public class ConcretePlaylist implements Playlist {
    private List<Song> songs;
    private List<Observer> observers;

    public ConcretePlaylist() {
        this.songs = new ArrayList<>();
        this.observers = new ArrayList<>();
    }

    @Override
    public void addSong(Song song) {
        songs.add(song);
        notifyObservers();
    }

    @Override
    public void removeSong(Song song) {
        songs.remove(song);
        notifyObservers();
    }

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }

    @Override
    public List<Song> getSongs() {
        return songs;
    }

}