public interface Song {
    String getTitle();
    String getArtist();
}
