public class ConcreteObserver implements Observer {
    private String name;

    public ConcreteObserver(String name) {
        this.name = name;
    }

    @Override
    public void update(Playlist playlist) {
        System.out.println(name + " received a notification: The playlist has been updated.");
    }
}