public class ConcreteSongFactory implements SongFactory {
    @Override
    public Song createSong(String title, String artist) {
        return new ConcreteSong(title, artist);
    }
}