public interface Observer {
    void update(Playlist playlist);
}