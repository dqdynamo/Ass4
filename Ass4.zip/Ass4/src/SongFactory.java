public interface SongFactory {
    Song createSong(String title, String artist);
}