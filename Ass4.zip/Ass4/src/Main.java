import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        SongFactory songFactory = new ConcreteSongFactory();


        Playlist playlist = new ConcretePlaylist();


        while (true) {
            System.out.println("1. Add a song to a playlist");
            System.out.println("2. Show playlist");
            System.out.println("3. Remove a song");
            System.out.println("4. Subscribe");
            System.out.println("5. Unsubscribe");
            System.out.println("6. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:

                    System.out.print("Enter the name of the song: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter the artist's name: ");
                    String artist = scanner.nextLine();

                    Song song = songFactory.createSong(title, artist);

                    playlist.addSong(song);

                    System.out.println("The song added to the playlist.");
                    break;
                case 2:
                    List<Song> songs = playlist.getSongs();
                    System.out.println("Playlist:");
                    for (Song s : songs) {
                        System.out.println("name of song " + s.getTitle() + ", Artist: " + s.getArtist());
                    }
                    break;
                case 3:
                    if (playlist.getSongs().isEmpty()) {
                        System.out.println("The playlist is empty. ");
                    } else {
                        System.out.print("Enter the name of the song you want to delete: ");
                        String songTitle = scanner.nextLine();
                        Song songToRemove = null;
                        for (Song s : playlist.getSongs()) {
                            if (s.getTitle().equalsIgnoreCase(songTitle)) {
                                songToRemove = s;
                                break;
                            }
                        }
                        if (songToRemove != null) {
                            playlist.removeSong(songToRemove);
                            System.out.println("The song removed from the playlist.");
                        } else {
                            System.out.println("The song with this name was not found in the playlist.");
                        }
                    }
                    break;
                case 4:
                    System.out.print("Enter name ");
                    String userName = scanner.nextLine();
                    Observer user = new ConcreteObserver(userName);
                    playlist.addObserver(user);
                    break;
                case 5:
                    System.out.print("Enter your name to unsubscribe: ");
                    String unsubscribedUserName = scanner.nextLine();
                    Observer unsubscribedUser = new ConcreteObserver(unsubscribedUserName);
                    playlist.removeObserver(unsubscribedUser);
                    break;
                case 6:
                    System.exit(0);
                default:
                    System.out.println("Please select an action from the list.");
            }
        }
    }
}
