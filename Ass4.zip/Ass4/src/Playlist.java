import java.util.List;

public interface Playlist {
    void addSong(Song song);
    void removeSong(Song song);
    void addObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
    List<Song> getSongs();
}